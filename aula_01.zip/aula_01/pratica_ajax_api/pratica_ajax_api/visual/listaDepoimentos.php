<?php
define('_BASE', $_SERVER['DOCUMENT_ROOT'] . '/dev web II/ajax/pratica_ajax_api/pratica_ajax_api/');

require_once _BASE . 'modelo/Conexao.php';
require_once _BASE . 'modelo/Depoimento.php';
require_once _BASE . 'modelo/DaoDepoimento.php';

$daoDepoimento = new DaoDepoimento();
$lista = $daoDepoimento->getLista();

echo json_encode($lista);