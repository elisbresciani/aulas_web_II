<?php
define('_BASE', $_SERVER['DOCUMENT_ROOT'] . '/dev web II/ajax/pratica_ajax_api/pratica_ajax_api/');

require_once _BASE . 'modelo/Conexao.php';
require_once _BASE . 'modelo/Depoimento.php';
require_once _BASE . 'modelo/DaoDepoimento.php';

$resposta = ['status'=>'erro'];

$codigoIbge = $_POST['codigoIbge'];
$nomeIbge = $_POST['nomeIbge'];
$comentario = $_POST['comentario'];

$depoimento = new Depoimento();
$depoimento->setCodigoIbge($codigoIbge);
$depoimento->setNomeIbge($nomeIbge);
$depoimento->setComentario($comentario);

$daoDepoimento = new DaoDepoimento();
if($daoDepoimento->incluir($depoimento))
{
    $resposta = ['status'=>'ok'];
}

echo json_encode($resposta);
